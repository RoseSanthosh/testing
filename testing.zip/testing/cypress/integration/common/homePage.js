
export default class HomePage {
    visit() {
        cy.visit('http://jupiter.cloud.planittesting.com');
    }

    clickCollapseIcon() {
        cy.get('a.btn-navbar').click();
    }

    navigateToPage(pageName) {
        cy.get(`a[href="#/${pageName}"]`).eq(0).click();
    }
}