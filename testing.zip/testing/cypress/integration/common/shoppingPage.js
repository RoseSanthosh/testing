
export default class ShoppingPage {
    buyItems(itemNumber, itemName) {
        cy.get('h4.product-title').contains(itemName)
            .parent()
            .find('span.product-price')
            .next('a.btn-success').then((button) => {
                for (let i = 0; i < itemNumber; i++) {
                    cy.wrap(button).click();
                }
            });
    }

    checkPriceAndTotals(text, price, itemName) {
        cy.contains('td.ng-binding', itemName)
            .next()
            .should('contain', price);
    }

    checkTotals() {
        let subtotal1, subtotal2, subtotal3, totals;
        cy.wrap(Promise.all([
            cy.get('tr.cart-item').eq(0).find('td:nth-child(4)').invoke('text').then((val) => {
                subtotal1 = parseFloat(val.replace('$', ''));
            }),
            cy.get('tr.cart-item').eq(1).find('td:nth-child(4)').invoke('text').then((val) => {
                subtotal2 = parseFloat(val.replace('$', ''));
            }),
            cy.get('tr.cart-item').eq(2).find('td:nth-child(4)').invoke('text').then((val) => {
                subtotal3 = parseFloat(val.replace('$', ''));
            }),
        ])).then(() => {
            let sumtotals = subtotal1 + subtotal2 + subtotal3;
            cy.get('td strong.total.ng-binding').invoke('text').then((val) => {
                totals = parseFloat(val.replace('Total: ', ''));

                expect(totals).to.equal(sumtotals);
            })
        });
    }

    checkItemSubtotal(text, itemName) {
        let quantityValue, priceText, subTotal, itemSubTotal;
        let index = itemName == "Stuffed Frog" ? 0 : itemName == "Fluffy Bunny" ? 1 : 2;
        cy.get('tr.cart-item').eq(index).contains('td', itemName).parent('tr').within(() => {
            cy.get('input[name="quantity"]').invoke('val').then((val) => {
                quantityValue = parseFloat(val.replace('$', ''));
                cy.get('td.ng-binding').eq(1).invoke('text').then((text) => {
                    priceText = parseFloat(text.replace('$', ''));
                    subTotal = quantityValue * priceText;
                    cy.get('td.ng-binding').eq(2).invoke('text').then((text) => {
                        itemSubTotal = text;
                        expect(itemSubTotal).to.equal('$' + subTotal);
                    });
                });
            });
        });
    }
}