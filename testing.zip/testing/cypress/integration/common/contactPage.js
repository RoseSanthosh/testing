
export default class ContactPage {
    clickSubmitButton() {
        cy.get('a.btn-contact').click();
    }

    checkErrorMessageVisibility(text, errorMessage) {
        switch (text) {
            case "should":
                cy.contains('.alert-error', errorMessage).should('be.visible');
                break;
            case "should not":
                cy.get('.alert-error').should('not.exist');
                break;
            default:
                cy.log('default case');
        }
    }

    checkValidationMessageVisibility(text, validationMessage, fieldName) {
        switch (text) {
            case "should see":
                cy.get(`.controls span#${fieldName}-err`).should('contain', validationMessage);
                break;
            case "should not see":
                cy.get(`.controls span#${fieldName}-err`).should('not.exist');
                break;
            default:
                cy.log('default case');
        }
    }

    checkErrorExistence() {
        cy.get('.alert-error').should('exist');
    }

    typeInField(value, fieldName) {
        cy.get(`#${fieldName}`).type(value);
    }

    checkSuccessMessageVisibility(text, successMessage) {
        cy.contains('.alert-success', successMessage, { timeout: 15000 }).should('be.visible');
    }
}