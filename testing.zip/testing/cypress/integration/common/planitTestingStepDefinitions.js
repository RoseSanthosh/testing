import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import HomePage from "./homePage";
import ContactPage from "./contactPage";
import ShoppingPage from "./shoppingPage";


const homePage = new HomePage();

const contactPage = new ContactPage();

const shoppingPage = new ShoppingPage();

Given('I am on the home page', () => {
    homePage.visit();
})

When('I click on the collapse icon', () => {
    homePage.clickCollapseIcon();
})

When('I navigate to the {string} page', (pageName) => {
    homePage.navigateToPage(pageName);
})

When('I click the submit button', () => {
    contactPage.clickSubmitButton();
})

Then('I {string} the error message {string} displayed', (text, errorMessage) => {
    contactPage.checkErrorMessageVisibility(text, errorMessage);
})

Then('I {string} the validation message {string} displayed for the {string} field', (text, validationMessage, fieldName) => {
    contactPage.checkValidationMessageVisibility(text, validationMessage, fieldName);
})

Given('I am on the contact page and error message displayed', () => {
    contactPage.checkErrorExistence()
})

When('I type the {string} in the {string} field', (value, fieldName) => {
    contactPage.typeInField(value, fieldName);
})

Then('I {string} the success message {string}', (text, successMessage) => {
    contactPage.checkSuccessMessageVisibility(text, successMessage);
})

When('I buy {int} {string} items from the {string} page', (itemNumber, itemName, pageName) => {
    shoppingPage.buyItems(itemNumber, itemName);

})

Then('I {string} the price {string} for {string}', (text, price, itemName) => {
    shoppingPage.checkPriceAndTotals(text, price, itemName);
})

Then('I {string} the totals is the sum of subtotals', (text) => {
    shoppingPage.checkTotals();
})

Then('I {string} the subtotal for {string} is correct', (text, itemName) => {
    shoppingPage.checkItemSubtotal(text, itemName);
})