import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";


Given('I am on the home page', () => {
    cy.visit('http://jupiter.cloud.planittesting.com');
})

When('I click on the collapse icon', () => {
    cy.get('a.btn-navbar').click();
})

When('I navigate to the {string} page', (pageName) => {
    cy.get(`a[href="#/${pageName}"]`).eq(0).click();
})

When('I click the submit button', () => {
    cy.get('a.btn-contact').click();
})

Then('I {string} the error message {string} displayed', (text, errorMessage) => {
    cy.contains('.alert-error', errorMessage).should('be.visible');
})

Then('I {string} the validation message {string} displayed for the {string} field', (text, validationMessage, fieldName) => {
    switch (text) {
        case "should see":
            cy.get(`.controls span#${fieldName}-err`).should('contain', validationMessage);
            break;
        case "should not see":
            cy.get(`.controls span#${fieldName}-err`).should('not.exist');
            break;

        default:
            cy.log('default case')
    }
})

Given('I am on the contact page and error message displayed', () => {
    cy.get('.alert-error').should('exist');
})

When('I type the {string} in the {string} field', (value, fieldName) => {
    cy.get(`#${fieldName}`).type(value);
})

Then('I {string} the success message {string}', (text, successMessage) => {
    cy.contains('.alert-success', successMessage, { timeout: 15000 }).should('be.visible');
})

When('I buy {int} {string} items from the {string} page', (itemNumber, itemName, pageName) => {
    cy.get('h4.product-title').contains(itemName)
        .parent()
        .find('span.product-price')
        .next('a.btn-success').then((button) => {
            for (let i = 0; i < itemNumber; i++) {
                cy.wrap(button).click();
            }
        })

})

Then('I {string} the price {string} for {string}', (text, price, itemName) => {
    cy.contains('td.ng-binding', itemName)
        .next()
        .should('contain', price);
})

Then('I {string} the totals is the sum of subtotals', (text) => {
    let subtotal1, subtotal2, subtotal3, totals;
    cy.wrap(Promise.all([
        cy.get('tr.cart-item').eq(0).find('td:nth-child(4)').invoke('text').then((val) => {
            subtotal1 = parseFloat(val.replace('$', ''));
        }),
        cy.get('tr.cart-item').eq(1).find('td:nth-child(4)').invoke('text').then((val) => {
            subtotal2 = parseFloat(val.replace('$', ''));
        }),
        cy.get('tr.cart-item').eq(2).find('td:nth-child(4)').invoke('text').then((val) => {
            subtotal3 = parseFloat(val.replace('$', ''));
        }),
    ])).then(() => {
        let sumtotals = subtotal1 + subtotal2 + subtotal3;
        cy.get('td strong.total.ng-binding').invoke('text').then((val) => {
            totals = parseFloat(val.replace('Total: ', ''));

            expect(totals).to.equal(sumtotals);
        })
    });
})

Then('I {string} the subtotal for {string} is correct', (text, itemName) => {
    let quantityValue, priceText, subTotal, itemSubTotal;
    let index = itemName == "Stuffed Frog" ? 0 : itemName == "Fluffy Bunny" ? 1 : 2;
    cy.get('tr.cart-item').eq(index).contains('td', itemName).parent('tr').within(() => {
        cy.get('input[name="quantity"]').invoke('val').then((val) => {
            quantityValue = parseFloat(val.replace('$', ''));
            cy.get('td.ng-binding').eq(1).invoke('text').then((text) => {
                priceText = parseFloat(text.replace('$', ''));
                subTotal = quantityValue * priceText;
                cy.get('td.ng-binding').eq(2).invoke('text').then((text) => {
                    itemSubTotal = text;
                    expect(itemSubTotal).to.equal('$'+ subTotal);
                })
            })
        })
    })
})