const { defineConfig } = require("cypress");

// module.exports = defineConfig({
//   e2e: {
//     baseUrl: 'https://practicetestautomation.com/practice-test-login/',
//     setupNodeEvents(on, config) {
//       // implement node event listeners here
//     },
//   },
// });


const createBundler = require("@bahmutov/cypress-esbuild-preprocessor");
const preprocessor = require("@badeball/cypress-cucumber-preprocessor");
const createEsbuildPlugin = require("@badeball/cypress-cucumber-preprocessor/esbuild");

module.exports = defineConfig({
    viewportHeight: 823,
    viewportWidth: 411,
    chromeWebSecurity: false,
    video: false,
    requestTimeout: 10000,
    numTestsKeptInMemory: 10,
    retries: {
        runMode: 0,
        openMode: 0
    },
    includeShadowDom: true,

    e2e: {
        baseUrl: null,
        specPattern: 'cypress/integration/**/*.feature',
        supportFile: 'cypress/support/e2e.js',
        watchForFileChanges: true,
        async setupNodeEvents(on, config) {

            await preprocessor.addCucumberPreprocessorPlugin(on, config);
            on(
                "file:preprocessor",
                createBundler({
                    plugins: [createEsbuildPlugin.default(config)],
                })
            );

            return require('./cypress/plugins/index.js')(on, config)
        },
    },
})