{/* <reference types="cypress" /> */}


const configWithDotenv = require('dotenv').config({ path: 'C:/Users/roses/OneDrive/Documents/cypress/.env' });

module.exports = (on, config) => {

    if(configWithDotenv.error) {
        throw configWithDotenv.error;
    }
    const env = { ...config.env, ...configWithDotenv.parsed };
    const result = { ...config, env };
    return result;
}