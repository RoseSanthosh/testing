import {When, Then} from "@badeball/cypress-cucumber-preprocessor";

/* funtion to visit the url */
When('I open the page',() => {
    let loginUrl = Cypress.env(`DEFAULT_URL`);
    cy.visit(loginUrl);
})


/* funtion to enter username and password to login */
When('I enter {string} {string} into {string} field', (item, value, fieldName) => {
    cy.get(`[name=${item}]`).type(value);
})


/* funtion to click on the submit button */
When('I click the {string} button', (buttonName) => {
    cy.get(`[id=${buttonName}]`).click();
})


/* funtion to display the error message */
Then('I {string} the error message displayed', (text) => {
    cy.get('[id="error"]').should('be.visible');
})


/* funtion to display the text in the error message */
Then('I {string} the error message text {string}', (text, errorMessage) => {
    cy.get('[id="error"]').should('contain', errorMessage);
})