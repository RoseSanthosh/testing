import {Then} from "@badeball/cypress-cucumber-preprocessor";

/* funtion to view the new url in the logged in page */
Then('I {string} the new page url contains {string}', (text, value) => {
    cy.get('head > link[rel="canonical"]')
  .should('have.attr', 'href', value)
});

/* funtion to view the successfull message and log out button in the logged in page */
Then('I {string} the new page contains {string} {string}', (text, item, value) => {
  cy.get('#loop-container > div > article > div.post-content')
  .invoke('text')
  .as('parentText');
  let page;
  cy.get('@parentText').then((parentText) => {
    page = item == "message" ? 'p.has-text-align-center > strong' : 'div > div > div > a'
    cy.get(`${page}`).should('contain',value);
  })
});